############################################################################################
#Population density and basic reproductive number of COVID-19 across United States counties#
#Authors: Karla Therese L. Sy, Laura F. White, Brooke E. Nichols                           #
#Code for main analysis                                                                    #
#Updated August 24 2020                                                                    #
############################################################################################

#clear workspace
remove(list = ls())

#set working directory
setwd("WORKING DIRECTORY")

#read data
load("Sy_USDensityR0_Data.RData")

############################################################################################

##FIGURE 2 - POPULATION DENSITY THRESHOLD##

#compare density of counties with oubreaks vs counties without outbreak

county_outbreak_yn %>%
  group_by(included) %>%
  summarise(mean=median(Density,na.rm=TRUE), lower_IQR=summary(Density)[2], upper_IQR=summary(Density)[5], min=summary(Density)[1], max=summary(Density)[6])

summary(county_outbreak_yn$Density)
wilcox.test(county_outbreak_yn$Density~county_outbreak_yn$included)

#boxplot of counties with oubreaks vs counties without outbreak

county_outbreak_yn$included <- as.factor(county_outbreak_yn$included)

p <- ggplot(county_outbreak_yn, aes(included, Density)) + geom_boxplot(fill="gray92", width=0.5) + ylim(0,200) + theme_minimal() + ylab("Population Density (population/sq km)") + xlab("United States Counties") + theme_minimal(base_size=13)

tiff("Figure2.tiff", width=7, height=6, units="in", res=200)
plot(p)
graphics.off()

############################################################################################

##TABLE 1 - LINEAR MIXED MODELS##

#linear mixed models of R0 and density
table1model1 <- lme(R ~ density_log , random = ~ 1| state, data = county_R0_demog)
summary(table1model1)
intervals(table1model1)

#linear mixed models of R0 and density + % private transportation
table1model2 <- lme(R ~ density_log + private , random = ~ 1| state, data = county_R0_demog)
summary(table1model2)
intervals(table1model2)

#linear mixed models of R0 and density + % private transportation + median income
table1model3 <- lme(R ~ density_log + private + hincome, random = ~ 1| state, data = county_R0_demog)
summary(table1model3)
intervals(table1model3)

#linear mixed models of R0 and density + % private transportation + median income + interaction of density and % private transportation
table1model4 <- lme(R ~ density_log*private + hincome , random = ~ 1| state, data = county_R0_demog)
summary(table1model4)
intervals(table1model4)

############################################################################################

##TABLE 2 - SENSITIVITY ANALYSIS##

##a. Deaths only - Subset counties with R0 from deaths only##
county_R0_demog_a <- subset(county_R0_demog, !is.na(county_R0_demog$R_death))

#linear mixed models of R0 (death) and density 
table2model1_a <- lme(R_death ~ density_log , random = ~ 1| state, data = county_R0_demog_a)
summary(table2model1_a)
intervals(table2model1_a)

#linear mixed models of R0 (death) and density + % private transportation
table2model2_a <- lme(R_death~ density_log + private , random = ~ 1| state, data = county_R0_demog_a)
summary(table2model2_a)
intervals(table2model2_a)

#linear mixed models of R0 (death) and density + % private transportation + median income
table2model3_a <- lme(R_death~ density_log + private + hincome, random = ~ 1| state, data = county_R0_demog_a)
summary(table2model3_a)
intervals(table2model3_a)

#linear mixed models of R0 (death) and density + % private transportation + median income + interaction of density and % private transportation
table2model4_a <- lme(R_death~ density_log*private + hincome, random = ~ 1| state, data = county_R0_demog_a)
summary(table2model4_a)
intervals(table2model4_a)

###############################

##b. No counties adjacent to high density counties - within 15 mile radius, high density > 144.0492 population/sq km##
county_R0_demog_b <- county_R0_demog[county_R0_demog$sensitivitydensity,]

#linear mixed models of R0 and density (no counties adjacent to high density counties)
table2model1_b <- lme(R ~ density_log , random = ~ 1| state, data = county_R0_demog_b)
summary(table2model1_b)
intervals(table2model1_b)

#linear mixed models of R0 and density + % private transportation (no counties adjacent to high density counties)
table2model2_b <- lme(R ~ density_log + private , random = ~ 1| state, data = county_R0_demog_b)
summary(table2model2_b)
intervals(table2model2_b)

#linear mixed models of R0 and density + % private transportation + median income (no counties adjacent to high density counties)
table2model3_b <- lme(R ~ density_log + private + hincome, random = ~ 1| state, data = county_R0_demog_b)
summary(table2model3_b)
intervals(table2model3_b)

#linear mixed models of R0 and density + % private transportation + median income + interaction of density and % private transportation (no counties adjacent to high density counties)
table2model4_b <- lme(R ~ density_log*private + hincome , random = ~ 1| state, data = county_R0_demog_b)
summary(table2model4_b)
intervals(table2model4_b)

###############################

##c. Removing high influence counties - Cook's D over 4/N for each model)

#linear mixed models of R0 and density (no outliers)
sample_size<-nobs(table1model1)
cooksd1 <- CookD(table1model1)
influential <- as.numeric(names(cooksd1)[(cooksd1 > (4/sample_size))])
county_R0_demog_c <- county_R0_demog[-influential, ]
table1model1_c <- lme(R ~ density_log , random = ~ 1| state, data = county_R0_demog_c)
summary(table1model1_c)
intervals(table1model1_c)

#linear mixed models of R0 and density + % private transportation (no outliers)
sample_size<-nobs(table1model2)
cooksd1 <- CookD(table1model2)
influential <- as.numeric(names(cooksd1)[(cooksd1 > (4/sample_size))])
county_R0_demog_c <- county_R0_demog[-influential, ]
table1model2_c <- lme(R ~ density_log + private , random = ~ 1| state, data = county_R0_demog_c)
summary(table1model2_c)
intervals(table1model2_c)

#linear mixed models of R0 and density + % private transportation + median income (no outliers)
sample_size<-nobs(table1model3)
cooksd1 <- CookD(table1model3)
influential <- as.numeric(names(cooksd1)[(cooksd1 > (4/sample_size))])
county_R0_demog_c <- county_R0_demog[-influential, ]
table1model3_c <- lme(R ~ density_log + private + hincome, random = ~ 1| state, data = county_R0_demog_c)
summary(table1model3_c)
intervals(table1model3_c)

#linear mixed models of R0 and density + % private transportation + median income + interaction of density and % private transportation (no outliers)
sample_size<-nobs(table1model4)
cooksd1 <- CookD(table1model4)
influential <- as.numeric(names(cooksd1)[(cooksd1 > (4/sample_size))])
county_R0_demog_c <- county_R0_demog[-influential, ]
table1model4_c <- lme(R ~ density_log*private + hincome, random = ~ 1| state, data = county_R0_demog_c)
summary(table1model4_c)
intervals(table1model4_c)

